module.exports = {
    // mongoURI:"mongodb://localhost:27017"
    mongoURI:"mongodb+srv://admin:1password1@cluster0-yauku.mongodb.net/test?retryWrites=true&w=majority"
}